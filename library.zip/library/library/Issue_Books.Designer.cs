﻿namespace library
{
    partial class Issue_Books
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.Enrolment_textBox = new System.Windows.Forms.TextBox();
            this.Search_button = new System.Windows.Forms.Button();
            this.Sname_textBox = new System.Windows.Forms.TextBox();
            this.Dept_textBox = new System.Windows.Forms.TextBox();
            this.Sem_textBox = new System.Windows.Forms.TextBox();
            this.Contact_textBox = new System.Windows.Forms.TextBox();
            this.Email_textBox = new System.Windows.Forms.TextBox();
            this.Bname_textBox = new System.Windows.Forms.TextBox();
            this.Sname_label = new System.Windows.Forms.Label();
            this.dept_label = new System.Windows.Forms.Label();
            this.Sem_label = new System.Windows.Forms.Label();
            this.Contact_label = new System.Windows.Forms.Label();
            this.Email_label = new System.Windows.Forms.Label();
            this.Bname_label = new System.Windows.Forms.Label();
            this.Enrolment_label = new System.Windows.Forms.Label();
            this.Issue_label = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.Isuue_button = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.listBox1);
            this.panel1.Controls.Add(this.Isuue_button);
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Controls.Add(this.Issue_label);
            this.panel1.Controls.Add(this.Enrolment_label);
            this.panel1.Controls.Add(this.Bname_label);
            this.panel1.Controls.Add(this.Email_label);
            this.panel1.Controls.Add(this.Contact_label);
            this.panel1.Controls.Add(this.Sem_label);
            this.panel1.Controls.Add(this.dept_label);
            this.panel1.Controls.Add(this.Sname_label);
            this.panel1.Controls.Add(this.Bname_textBox);
            this.panel1.Controls.Add(this.Email_textBox);
            this.panel1.Controls.Add(this.Contact_textBox);
            this.panel1.Controls.Add(this.Sem_textBox);
            this.panel1.Controls.Add(this.Dept_textBox);
            this.panel1.Controls.Add(this.Sname_textBox);
            this.panel1.Controls.Add(this.Search_button);
            this.panel1.Controls.Add(this.Enrolment_textBox);
            this.panel1.Location = new System.Drawing.Point(27, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1123, 558);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // Enrolment_textBox
            // 
            this.Enrolment_textBox.Location = new System.Drawing.Point(101, 66);
            this.Enrolment_textBox.Name = "Enrolment_textBox";
            this.Enrolment_textBox.Size = new System.Drawing.Size(224, 22);
            this.Enrolment_textBox.TabIndex = 1;
            // 
            // Search_button
            // 
            this.Search_button.Location = new System.Drawing.Point(247, 19);
            this.Search_button.Name = "Search_button";
            this.Search_button.Size = new System.Drawing.Size(127, 23);
            this.Search_button.TabIndex = 2;
            this.Search_button.Text = "Search Student";
            this.Search_button.UseVisualStyleBackColor = true;
            this.Search_button.Click += new System.EventHandler(this.Search_button_Click);
            // 
            // Sname_textBox
            // 
            this.Sname_textBox.Location = new System.Drawing.Point(786, 19);
            this.Sname_textBox.Name = "Sname_textBox";
            this.Sname_textBox.Size = new System.Drawing.Size(284, 22);
            this.Sname_textBox.TabIndex = 3;
            // 
            // Dept_textBox
            // 
            this.Dept_textBox.Location = new System.Drawing.Point(786, 66);
            this.Dept_textBox.Name = "Dept_textBox";
            this.Dept_textBox.Size = new System.Drawing.Size(284, 22);
            this.Dept_textBox.TabIndex = 4;
            // 
            // Sem_textBox
            // 
            this.Sem_textBox.Location = new System.Drawing.Point(786, 119);
            this.Sem_textBox.Name = "Sem_textBox";
            this.Sem_textBox.Size = new System.Drawing.Size(284, 22);
            this.Sem_textBox.TabIndex = 5;
            // 
            // Contact_textBox
            // 
            this.Contact_textBox.Location = new System.Drawing.Point(786, 176);
            this.Contact_textBox.Name = "Contact_textBox";
            this.Contact_textBox.Size = new System.Drawing.Size(284, 22);
            this.Contact_textBox.TabIndex = 6;
            // 
            // Email_textBox
            // 
            this.Email_textBox.Location = new System.Drawing.Point(786, 230);
            this.Email_textBox.Name = "Email_textBox";
            this.Email_textBox.Size = new System.Drawing.Size(284, 22);
            this.Email_textBox.TabIndex = 7;
            // 
            // Bname_textBox
            // 
            this.Bname_textBox.Location = new System.Drawing.Point(786, 324);
            this.Bname_textBox.Name = "Bname_textBox";
            this.Bname_textBox.Size = new System.Drawing.Size(284, 22);
            this.Bname_textBox.TabIndex = 8;
            this.Bname_textBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Bname_textBox_KeyDown);
            this.Bname_textBox.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Bname_textBox_KeyUp);
            // 
            // Sname_label
            // 
            this.Sname_label.AutoSize = true;
            this.Sname_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sname_label.Location = new System.Drawing.Point(632, 19);
            this.Sname_label.Name = "Sname_label";
            this.Sname_label.Size = new System.Drawing.Size(110, 17);
            this.Sname_label.TabIndex = 9;
            this.Sname_label.Text = "Student Name";
            // 
            // dept_label
            // 
            this.dept_label.AutoSize = true;
            this.dept_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dept_label.Location = new System.Drawing.Point(632, 66);
            this.dept_label.Name = "dept_label";
            this.dept_label.Size = new System.Drawing.Size(92, 17);
            this.dept_label.TabIndex = 10;
            this.dept_label.Text = "Department";
            // 
            // Sem_label
            // 
            this.Sem_label.AutoSize = true;
            this.Sem_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sem_label.Location = new System.Drawing.Point(632, 120);
            this.Sem_label.Name = "Sem_label";
            this.Sem_label.Size = new System.Drawing.Size(76, 17);
            this.Sem_label.TabIndex = 11;
            this.Sem_label.Text = "Semester";
            // 
            // Contact_label
            // 
            this.Contact_label.AutoSize = true;
            this.Contact_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Contact_label.Location = new System.Drawing.Point(632, 176);
            this.Contact_label.Name = "Contact_label";
            this.Contact_label.Size = new System.Drawing.Size(124, 17);
            this.Contact_label.TabIndex = 12;
            this.Contact_label.Text = "Contact Number";
            // 
            // Email_label
            // 
            this.Email_label.AutoSize = true;
            this.Email_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Email_label.Location = new System.Drawing.Point(632, 232);
            this.Email_label.Name = "Email_label";
            this.Email_label.Size = new System.Drawing.Size(67, 17);
            this.Email_label.TabIndex = 13;
            this.Email_label.Text = "Email ID";
            // 
            // Bname_label
            // 
            this.Bname_label.AutoSize = true;
            this.Bname_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bname_label.Location = new System.Drawing.Point(632, 326);
            this.Bname_label.Name = "Bname_label";
            this.Bname_label.Size = new System.Drawing.Size(90, 17);
            this.Bname_label.TabIndex = 14;
            this.Bname_label.Text = "Book Name";
            // 
            // Enrolment_label
            // 
            this.Enrolment_label.AutoSize = true;
            this.Enrolment_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Enrolment_label.Location = new System.Drawing.Point(3, 19);
            this.Enrolment_label.Name = "Enrolment_label";
            this.Enrolment_label.Size = new System.Drawing.Size(216, 20);
            this.Enrolment_label.TabIndex = 15;
            this.Enrolment_label.Text = "Enter Enrolment Number";
            // 
            // Issue_label
            // 
            this.Issue_label.AutoSize = true;
            this.Issue_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Issue_label.Location = new System.Drawing.Point(632, 276);
            this.Issue_label.Name = "Issue_label";
            this.Issue_label.Size = new System.Drawing.Size(134, 17);
            this.Issue_label.TabIndex = 1;
            this.Issue_label.Text = "Books Issue Date";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(786, 276);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(284, 22);
            this.dateTimePicker1.TabIndex = 16;
            // 
            // Isuue_button
            // 
            this.Isuue_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Isuue_button.Location = new System.Drawing.Point(38, 422);
            this.Isuue_button.Name = "Isuue_button";
            this.Isuue_button.Size = new System.Drawing.Size(130, 29);
            this.Isuue_button.TabIndex = 17;
            this.Isuue_button.Text = "Isuue Book";
            this.Isuue_button.UseVisualStyleBackColor = true;
            this.Isuue_button.Click += new System.EventHandler(this.Isuue_button_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(786, 342);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(284, 164);
            this.listBox1.TabIndex = 18;
            this.listBox1.Visible = false;
            this.listBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.listBox1_KeyDown);
            // 
            // Issue_Books
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1183, 558);
            this.Controls.Add(this.panel1);
            this.Name = "Issue_Books";
            this.Text = "Issue_Books";
            this.Load += new System.EventHandler(this.Issue_Books_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Search_button;
        private System.Windows.Forms.TextBox Enrolment_textBox;
        private System.Windows.Forms.Label Enrolment_label;
        private System.Windows.Forms.Label Bname_label;
        private System.Windows.Forms.Label Email_label;
        private System.Windows.Forms.Label Contact_label;
        private System.Windows.Forms.Label Sem_label;
        private System.Windows.Forms.Label dept_label;
        private System.Windows.Forms.Label Sname_label;
        private System.Windows.Forms.TextBox Bname_textBox;
        private System.Windows.Forms.TextBox Email_textBox;
        private System.Windows.Forms.TextBox Contact_textBox;
        private System.Windows.Forms.TextBox Sem_textBox;
        private System.Windows.Forms.TextBox Dept_textBox;
        private System.Windows.Forms.TextBox Sname_textBox;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label Issue_label;
        private System.Windows.Forms.Button Isuue_button;
        private System.Windows.Forms.ListBox listBox1;
    }
}